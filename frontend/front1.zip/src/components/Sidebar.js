import {
  Link,
  useLocation
} from 'react-router-dom';

function Sidebar() {
  const location = useLocation();

  const user = JSON.parse(
    localStorage.getItem('user')
  );

  return (
    <div className="sidebar">
      <h1>FlowDesk</h1>

      <nav>
        <Link
          to="/"
          className={
            location.pathname === '/'
              ? 'active'
              : ''
          }
        >
          Dashboard
        </Link>

        <Link
          to="/leads"
          className={
            location.pathname ===
            '/leads'
              ? 'active'
              : ''
          }
        >
          Leads
        </Link>

        {(user?.role === 'Admin' ||
          user?.role ===
            'Admissions') && (
          <Link
            to="/reports"
            className={
              location.pathname ===
              '/reports'
                ? 'active'
                : ''
            }
          >
            Reports
          </Link>
        )}

        <Link
          to="/settings"
          className={
            location.pathname ===
            '/settings'
              ? 'active'
              : ''
          }
        >
          Settings
        </Link>

        {user?.role === 'Admin' && (
          <div className="role-badge">
            ADMIN ACCESS
          </div>
        )}

        {user?.role ===
          'Admissions' && (
          <div className="role-badge admissions">
            ADMISSIONS TEAM
          </div>
        )}

        {user?.role ===
          'Counselor' && (
          <div className="role-badge counselor">
            COUNSELOR
          </div>
        )}
      </nav>
    </div>
  );
}

export default Sidebar;