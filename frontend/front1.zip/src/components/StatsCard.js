function StatsCard({ title, value, color }) {
  return (
    <div className="card" style={{ borderLeft: `4px solid ${color || '#6c63ff'}` }}>
      <h3>{title}</h3>
      <p className="stat-value">{value ?? '—'}</p>
    </div>
  );
}

export default StatsCard;
