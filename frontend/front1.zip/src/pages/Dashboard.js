import { useEffect, useState } from 'react';

import API from '../services/api';

import StatsCard from '../components/StatsCard';

import Loader from '../components/Loader';

import socket from '../socket';

function Dashboard() {
  const [stats, setStats] =
    useState(null);

  const [error, setError] =
    useState('');

  const [loading, setLoading] =
    useState(true);

  /*
    FETCH STATS
  */
  const fetchStats =
    async () => {
      try {
        const res =
          await API.get(
            '/dashboard/stats'
          );

        setStats(res.data);

        setError('');
      } catch (err) {
        console.log(err);

        setError(
          'Failed to load dashboard stats.'
        );
      } finally {
        setLoading(false);
      }
    };

  /*
    INITIAL LOAD
  */
  useEffect(() => {
    fetchStats();
  }, []);

  /*
    SOCKET REALTIME
  */
  useEffect(() => {
    socket.on(
      'leadCreated',
      () => {
        fetchStats();
      }
    );

    return () => {
      socket.off(
        'leadCreated'
      );
    };
  }, []);

  /*
    LOADING
  */
  if (loading) {
    return <Loader />;
  }

  return (
    <div>
      <h2>Dashboard</h2>

      <p>
        Monitor leads,
        admissions and counselor
        performance.
      </p>

      {error && (
        <div className="error-msg">
          {error}
        </div>
      )}

      {stats && (
        <>
          <div className="stats-grid">
            <StatsCard
              title="Total Leads"
              value={
                stats.totalLeads || 0
              }
              color="#6C63FF"
            />

            <StatsCard
              title="Counselors"
              value={
                stats.counselors || 0
              }
              color="#8B5CF6"
            />

            <StatsCard
              title="Admissions Team"
              value={
                stats.admissions || 0
              }
              color="#06B6D4"
            />

            <StatsCard
              title="Admitted Leads"
              value={
                stats.admitted || 0
              }
              color="#22C55E"
            />

            <StatsCard
              title="Pending Followups"
              value={
                stats.pendingFollowups ||
                0
              }
              color="#F97316"
            />
          </div>

          <div className="dashboard-widgets">
            <div className="card">
              <h3>
                Quick Overview
              </h3>

              <p>
                Total conversion
                rate:
              </p>

              <h1>
                {stats.conversionRate ||
                  0}
                %
              </h1>
            </div>

            <div className="card">
              <h3>
                System Status
              </h3>

              <p>
                CRM system
                operational and
                running normally.
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default Dashboard;