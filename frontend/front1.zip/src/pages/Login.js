import { useState } from 'react';

import {
  useNavigate,
  Link
} from 'react-router-dom';

import API from '../services/api';

import { useAuth } from '../context/AuthContext';

function Login() {
  const [email, setEmail] = useState('');

  const [password, setPassword] =
    useState('');

  const [error, setError] =
    useState('');

  const [loading, setLoading] =
    useState(false);

  const { login } = useAuth();

  const navigate = useNavigate();

  const handleLogin = async () => {
    setError('');

    if (!email || !password) {
      setError(
        'Please fill in all fields.'
      );

      return;
    }

    setLoading(true);

    try {
      const res = await API.post(
        '/auth/login',
        {
          email,
          password
        }
      );

      /*
        STORE TOKEN
      */
      localStorage.setItem(
        'token',
        res.data.token
      );

      /*
        STORE USER
      */
      localStorage.setItem(
        'user',
        JSON.stringify(res.data.user)
      );

      /*
        AUTH CONTEXT LOGIN
      */
      login(
        res.data.token,
        res.data.user
      );

      /*
        ROLE-BASED REDIRECT
      */
      if (
        res.data.user.role === 'Admin'
      ) {
        navigate('/');
      } else if (
        res.data.user.role ===
        'Admissions'
      ) {
        navigate('/');
      } else {
        navigate('/');
      }
    } catch (err) {
      console.log(err);

      setError(
        err.response?.data?.message ||
          'Login failed. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-page">
        <h1>FlowDesk</h1>

        <h2>Welcome back</h2>

        <p>
          Login to continue managing
          leads and admissions.
        </p>

        {error && (
          <div className="error-msg">
            {error}
          </div>
        )}

        <input
          placeholder="Email Address"
          type="email"
          value={email}
          onChange={(e) =>
            setEmail(e.target.value)
          }
          onKeyDown={handleKeyDown}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) =>
            setPassword(
              e.target.value
            )
          }
          onKeyDown={handleKeyDown}
        />

        <button
          className="primary-btn"
          onClick={handleLogin}
          disabled={loading}
        >
          {loading
            ? 'Logging in...'
            : 'Login'}
        </button>

        <p className="auth-footer">
          Don&apos;t have an account?{' '}
          <Link to="/signup">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;