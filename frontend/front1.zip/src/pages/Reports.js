import {
  useEffect,
  useState
} from 'react';

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

import API from '../services/api';

function Reports() {
  const [data, setData] =
    useState([]);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports =
    async () => {
      try {
        const res =
          await API.get(
            '/reports/monthly'
          );

        const formatted =
          res.data.map((r) => ({
            month:
              r._id.month,
            leads:
              r.totalLeads,
            admitted:
              r.admitted
          }));

        setData(formatted);
      } catch (error) {
        console.log(error);
      }
    };

  return (
    <div>
      <h2>
        Reports & Analytics
      </h2>

      <div className="card">
        <ResponsiveContainer
          width="100%"
          height={350}
        >
          <BarChart data={data}>
            <XAxis dataKey="month" />

            <YAxis />

            <Tooltip />

            <Bar dataKey="leads" />

            <Bar dataKey="admitted" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default Reports;