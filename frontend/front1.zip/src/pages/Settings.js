import { useEffect, useState } from 'react';
import API from '../services/api';

function Settings() {
  const [profile, setProfile] = useState({
    name: '',
    email: ''
  });

  const [passwords, setPasswords] = useState({
    currentPassword: '',
    newPassword: ''
  });

  const [message, setMessage] = useState('');

  const [darkMode, setDarkMode] = useState(
    localStorage.getItem('darkMode') === 'true'
  );

  useEffect(() => {
    fetchProfile();
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }

    localStorage.setItem('darkMode', darkMode);
  }, [darkMode]);

  const fetchProfile = async () => {
    try {
      const res = await API.get('/auth/profile');

      setProfile({
        name: res.data.name,
        email: res.data.email
      });
    } catch (error) {
      console.log(error);
    }
  };

  const updateProfile = async () => {
    try {
      await API.put('/auth/profile', profile);

      setMessage('Profile updated successfully');
    } catch (error) {
      console.log(error);
    }
  };

  const updatePassword = async () => {
    try {
      await API.put('/auth/change-password', passwords);

      setMessage('Password updated successfully');

      setPasswords({
        currentPassword: '',
        newPassword: ''
      });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Settings</h2>
          <p>
            Manage account preferences and application settings.
          </p>
        </div>
      </div>

      {message && (
        <div className="success-message">
          {message}
        </div>
      )}

      <div className="settings-grid">
        <div className="card">
          <h3>PROFILE SETTINGS</h3>

          <input
            placeholder="Full Name"
            value={profile.name}
            onChange={(e) =>
              setProfile({
                ...profile,
                name: e.target.value
              })
            }
          />

          <input
            placeholder="Email Address"
            value={profile.email}
            onChange={(e) =>
              setProfile({
                ...profile,
                email: e.target.value
              })
            }
          />

          <button
            className="primary-btn"
            onClick={updateProfile}
          >
            Save Changes
          </button>
        </div>

        <div className="card">
          <h3>SECURITY</h3>

          <input
            type="password"
            placeholder="Current Password"
            value={passwords.currentPassword}
            onChange={(e) =>
              setPasswords({
                ...passwords,
                currentPassword: e.target.value
              })
            }
          />

          <input
            type="password"
            placeholder="New Password"
            value={passwords.newPassword}
            onChange={(e) =>
              setPasswords({
                ...passwords,
                newPassword: e.target.value
              })
            }
          />

          <button
            className="primary-btn"
            onClick={updatePassword}
          >
            Update Password
          </button>
        </div>

        <div className="card">
          <h3>APPEARANCE</h3>

          <div className="theme-toggle">
            <span>Dark Mode</span>

            <button
              className="toggle-btn"
              onClick={() =>
                setDarkMode(!darkMode)
              }
            >
              {darkMode ? 'Enabled' : 'Disabled'}
            </button>
          </div>
        </div>

        <div className="card">
          <h3>NOTIFICATIONS</h3>

          <label>
            <input type="checkbox" />
            Followup Alerts
          </label>

          <label>
            <input type="checkbox" />
            Email Notifications
          </label>

          <label>
            <input type="checkbox" />
            WhatsApp Alerts
          </label>
        </div>
      </div>
    </div>
  );
}

export default Settings;