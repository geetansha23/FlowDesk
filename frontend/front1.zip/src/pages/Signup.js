import { useState } from 'react';

import { useNavigate } from 'react-router-dom';

import API from '../services/api';

function Signup() {
  const navigate = useNavigate();

  const [formData, setFormData] =
    useState({
      name: '',
      email: '',
      password: '',
      role: 'Counselor'
    });

  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]:
        e.target.value
    });
  };

  const handleSignup = async (e) => {
    e.preventDefault();

    try {
      await API.post(
        '/auth/register',
        formData
      );

      navigate('/login');
    } catch (err) {
      console.log(err);

      setError(
        err.response?.data?.message ||
          'Signup failed'
      );
    }
  };

  return (
    <div className="auth-page">
      <form
        className="auth-form"
        onSubmit={handleSignup}
      >
        <h2>Create Account</h2>

        {error && (
          <div className="error-msg">
            {error}
          </div>
        )}

        <input
          type="text"
          name="name"
          placeholder="Full Name"
          value={formData.name}
          onChange={handleChange}
          required
        />

        <input
          type="email"
          name="email"
          placeholder="Email Address"
          value={formData.email}
          onChange={handleChange}
          required
        />

        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          required
        />

        <select
          name="role"
          value={formData.role}
          onChange={handleChange}
        >
          <option value="Counselor">
            Counselor
          </option>

          <option value="Admissions">
            Admissions
          </option>

          <option value="Admin">
            Admin
          </option>
        </select>

        <button
          type="submit"
          className="primary-btn"
        >
          Create Account
        </button>
      </form>
    </div>
  );
}

export default Signup;