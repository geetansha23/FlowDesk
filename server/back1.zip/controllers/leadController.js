const Lead = require('../models/Lead');

const logActivity = require(
  '../utils/logActivity'
);

/*
  GET ALL LEADS
*/
exports.getLeads = async (
  req,
  res
) => {
  try {
    const {
      search,
      status,
      country,
      page = 1,
      limit = 10
    } = req.query;

    /*
      QUERY OBJECT
    */
    let query = {
      isArchived: false
    };

    /*
      ROLE FILTERING
    */
    if (
      req.user &&
      req.user.role ===
        'Counselor'
    ) {
      query.assignedCounselor =
        req.user.name;
    }

    /*
      SEARCH FILTER
    */
    if (search) {
      query.$or = [
        {
          fullName: {
            $regex: search,
            $options: 'i'
          }
        },
        {
          email: {
            $regex: search,
            $options: 'i'
          }
        },
        {
          country: {
            $regex: search,
            $options: 'i'
          }
        }
      ];
    }

    /*
      STATUS FILTER
    */
    if (status) {
      query.leadStatus = status;
    }

    /*
      COUNTRY FILTER
    */
    if (country) {
      query.country = country;
    }

    /*
      PAGINATION
    */
    const pageNumber =
      Number(page);

    const limitNumber =
      Number(limit);

    const skip =
      (pageNumber - 1) *
      limitNumber;

    /*
      FETCH LEADS
    */
    const leads = await Lead.find(
      query
    )
      .sort({
        createdAt: -1
      })
      .skip(skip)
      .limit(limitNumber);

    /*
      TOTAL LEADS
    */
    const total =
      await Lead.countDocuments(
        query
      );

    /*
      RESPONSE
    */
    res.status(200).json({
      success: true,

      leads,

      currentPage:
        pageNumber,

      totalPages:
        Math.ceil(
          total / limitNumber
        ),

      totalLeads: total
    });
  } catch (error) {
    console.error(
      'Get Leads Error:',
      error
    );

    res.status(500).json({
      success: false,
      message:
        'Failed to fetch leads'
    });
  }
};

/*
  GET SINGLE LEAD
*/
exports.getLeadById = async (
  req,
  res
) => {
  try {
    const lead =
      await Lead.findById(
        req.params.id
      );

    if (!lead) {
      return res
        .status(404)
        .json({
          success: false,
          message:
            'Lead not found'
        });
    }

    res.status(200).json({
      success: true,
      lead
    });
  } catch (error) {
    console.error(
      'Get Lead Error:',
      error
    );

    res.status(500).json({
      success: false,
      message:
        'Failed to fetch lead'
    });
  }
};

/*
  CREATE LEAD
*/
exports.createLead = async (
  req,
  res
) => {
  try {
    /*
      CREATE
    */
    const lead = await Lead.create(
      req.body
    );

    /*
      ACTIVITY
    */
    try {
      await logActivity(
        lead._id,
        'Lead Created',
        req.user?.name ||
          'System'
      );
    } catch (activityError) {
      console.log(
        'Activity Log Error:',
        activityError.message
      );
    }

    res.status(201).json({
      success: true,
      lead
    });
  } catch (error) {
    console.error(
      'Create Lead Error:',
      error
    );

    res.status(500).json({
      success: false,
      message:
        'Failed to create lead'
    });
  }
};

/*
  UPDATE LEAD
*/
exports.updateLead = async (
  req,
  res
) => {
  try {
    const lead =
      await Lead.findByIdAndUpdate(
        req.params.id,
        req.body,
        {
          new: true,
          runValidators: true
        }
      );

    if (!lead) {
      return res
        .status(404)
        .json({
          success: false,
          message:
            'Lead not found'
        });
    }

    /*
      ACTIVITY
    */
    try {
      await logActivity(
        lead._id,
        'Lead Updated',
        req.user?.name ||
          'System'
      );
    } catch (activityError) {
      console.log(
        'Activity Log Error:',
        activityError.message
      );
    }

    res.status(200).json({
      success: true,
      lead
    });
  } catch (error) {
    console.error(
      'Update Lead Error:',
      error
    );

    res.status(500).json({
      success: false,
      message:
        'Failed to update lead'
    });
  }
};

/*
  ARCHIVE LEAD
*/
exports.deleteLead = async (
  req,
  res
) => {
  try {
    const lead =
      await Lead.findByIdAndUpdate(
        req.params.id,
        {
          isArchived: true
        },
        {
          new: true
        }
      );

    if (!lead) {
      return res
        .status(404)
        .json({
          success: false,
          message:
            'Lead not found'
        });
    }

    /*
      ACTIVITY
    */
    try {
      await logActivity(
        lead._id,
        'Lead Archived',
        req.user?.name ||
          'System'
      );
    } catch (activityError) {
      console.log(
        'Activity Log Error:',
        activityError.message
      );
    }

    res.status(200).json({
      success: true,
      message:
        'Lead archived successfully'
    });
  } catch (error) {
    console.error(
      'Delete Lead Error:',
      error
    );

    res.status(500).json({
      success: false,
      message:
        'Failed to archive lead'
    });
  }
};