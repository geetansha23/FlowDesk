const express = require('express');

const router = express.Router();

const auth = require('../middleware/authMiddleware');

const {
  register,
  login,
  getProfile,
  updateProfile,
  changePassword
} = require('../controllers/authController');
const User = require('../models/User');

/*
  GET ALL COUNSELORS
*/
router.get('/counselors', async (req, res) => {
  try {
    const counselors = await User.find({
      role: 'Counselor'
    }).select('_id name email role');

    res.json(counselors);
  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: 'Failed to fetch counselors'
    });
  }
});
router.post('/register', register);

router.post('/login', login);

router.get('/profile', auth, getProfile);

router.put('/profile', auth, updateProfile);

router.put(
  '/change-password',
  auth,
  changePassword
);

module.exports = router;